const entrada = require('readline-sync');

const peso = entrada.questionFloat('Digite o peso da peca (g): ');

if (peso >= 95 && peso <= 105) {
  console.log(`Peso: ${peso}g - a peça esta aprovada`);


} else {
  console.log(`Peso: ${peso}g - a peça esta reprovada`);
}

