const entrada = require('readline-sync');

const pecasciclo = entrada.questionInt('Digite a quantidade de pecas por ciclo: \n');

console.log('\n--- PRODUÇÃO ---');

for (let i = 1; i <= 10; i ++) {
  const prodacumulada = i * pecasciclo;

  console.log(`Ciclo ${i}: ${prodacumulada} peças acumuladas`);
}

