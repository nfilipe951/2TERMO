const entrada = require('readline-sync');

const opd = [];

for (let i = 0; i < 5; i++) {
  const nome = entrada.question(`Digite o nome do operador ${i + 1}: `);

  opd.push(nome);
}

console.log('\n--- lista dos nomes ---');

for (let i = 0; i < opd.length; i++) {
  console.log(`${i + 1}-${opd[i]}`);
}