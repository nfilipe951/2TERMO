const entrada = require('readline-sync');

const temperatura = entrada.questionFloat('Digite a temperatura da maquina: \n');

console.log(`A Temperatura é: ${temperatura}°C`);

if (temperatura <= 60) {

    console.log('Situacao estado normal');

} else if (temperatura <= 80) {
  console.log('Situacao estado atencao');

} else {
  console.log('Situacao estado critica');
}
