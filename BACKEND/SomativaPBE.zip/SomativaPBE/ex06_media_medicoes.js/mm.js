const entrada = require('readline-sync');


let soma = 0;
for (let i = 1; i <= 5; i++) {
  const medicao = entrada.questionFloat(`Digite o valor para a medicao ${i}:`);

  soma += medicao;
}


const media = soma / 5;

console.log(`a soma total das medições é: ${soma}`);
console.log(`a media final é: ${media}`);