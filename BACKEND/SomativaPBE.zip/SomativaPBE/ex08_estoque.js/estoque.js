
const entrada = require('readline-sync');

const estoque = [];

for (let i = 0; i < 3; i++) {
  console.log(`\n--- Cadastro ${i + 1} ---`);
  const nome = entrada.question('Digite o nome do componente: \n');
  const qtd = entrada.questionInt('Digite a quantidade atual: \n');
  const minimo = entrada.questionInt('Digite o estoque minimo: \n');

  estoque.push({nome, qtd, minimo });
}

console.log('RELATORIO');

for (let i = 0; i < estoque.length; i++) {
  const item = estoque[i];
  let status = 'Estoque ok';
 
  if (item.qtd < item.minimo) {
    status = 'Repor o estoque';
  }

  console.log(`Item: ${item.nome} | Qtd: ${item.quantidade} | Mín: ${item.estoqueMinimo} - ${status}`);
}