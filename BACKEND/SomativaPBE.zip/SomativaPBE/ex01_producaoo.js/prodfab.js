const pecasPorHora = 120;
const horasTurno = 8;
const producaoTotal = pecasPorHora * horasTurno;

console.log(`Produção por hora: ${pecasPorHora} peças`);
console.log(`Horas do turno: ${horasTurno}h`);
console.log(`Total produzido no turno: ${producaoTotal} peças`);